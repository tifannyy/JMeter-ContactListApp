/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 88.57142857142857, "KoPercent": 11.428571428571429};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.35, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5, 500, 1500, "Add Contact Request - 5"], "isController": false}, {"data": [0.5, 500, 1500, "Add Contact Request - 4"], "isController": false}, {"data": [0.5, 500, 1500, "Add Contact Request - 3"], "isController": false}, {"data": [0.0, 500, 1500, "GET_CONTACT"], "isController": true}, {"data": [0.5, 500, 1500, "Get Contact Request - 4"], "isController": false}, {"data": [0.4, 500, 1500, "ADD_CONTACT"], "isController": true}, {"data": [0.4, 500, 1500, "PATCH_UPDATE_CONTACT"], "isController": true}, {"data": [0.5, 500, 1500, "Get Contact Request - 5"], "isController": false}, {"data": [0.5, 500, 1500, "Get Contact Request - 2"], "isController": false}, {"data": [0.0, 500, 1500, "Update Contact Request - 2"], "isController": false}, {"data": [0.5, 500, 1500, "Update Contact Request - 1"], "isController": false}, {"data": [0.5, 500, 1500, "Get Contact Request - 3"], "isController": false}, {"data": [0.4, 500, 1500, "DELETE_CONTACT"], "isController": true}, {"data": [0.5, 500, 1500, "Get Contact Request - 1"], "isController": false}, {"data": [0.0, 500, 1500, "Add Contact Request - 2"], "isController": false}, {"data": [0.5, 500, 1500, "Add Contact Request - 1"], "isController": false}, {"data": [0.5, 500, 1500, "Update Contact Request - 4"], "isController": false}, {"data": [0.5, 500, 1500, "Update Contact Request - 3"], "isController": false}, {"data": [0.5, 500, 1500, "Update Contact Request - 5"], "isController": false}, {"data": [0.4, 500, 1500, "PUT_UPDATE_CONTACT"], "isController": true}, {"data": [0.5, 500, 1500, "Get Contact by ID Request - 1"], "isController": false}, {"data": [0.5, 500, 1500, "Get Contact by ID Request - 2"], "isController": false}, {"data": [0.5, 500, 1500, "Get Contact by ID Request - 3"], "isController": false}, {"data": [0.5, 500, 1500, "Get Contact by ID Request - 4"], "isController": false}, {"data": [0.5, 500, 1500, "Delete Contact Request - 5"], "isController": false}, {"data": [0.5, 500, 1500, "Get Contact by ID Request - 5"], "isController": false}, {"data": [0.5, 500, 1500, "Delete Contact Request - 3"], "isController": false}, {"data": [0.5, 500, 1500, "Delete Contact Request - 4"], "isController": false}, {"data": [0.5, 500, 1500, "Delete Contact Request - 1"], "isController": false}, {"data": [0.0, 500, 1500, "Delete Contact Request - 2"], "isController": false}, {"data": [0.0, 500, 1500, "AUTH Request"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 35, 4, 11.428571428571429, 2953.8571428571427, 3, 30877, 1051.0, 2830.3999999999996, 30393.799999999996, 30877.0, 0.5036188612458092, 0.706373229240111, 0.30252261338618935], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add Contact Request - 5", 1, 0, 0.0, 1049.0, 1049, 1049, 1049.0, 1049.0, 1049.0, 1049.0, 0.9532888465204957, 0.9895957459485225, 0.796889895138227], "isController": false}, {"data": ["Add Contact Request - 4", 1, 0, 0.0, 1050.0, 1050, 1050, 1050.0, 1050.0, 1050.0, 1050.0, 0.9523809523809523, 0.9867931547619048, 0.7905505952380952], "isController": false}, {"data": ["Add Contact Request - 3", 1, 0, 0.0, 1037.0, 1037, 1037, 1037.0, 1037.0, 1037.0, 1037.0, 0.9643201542912248, 1.012347818225651, 0.8023445033751206], "isController": false}, {"data": ["GET_CONTACT", 5, 0, 0.0, 2119.2, 2087, 2187, 2094.0, 2187.0, 2187.0, 2187.0, 0.42567682615358415, 1.8607564543248765, 0.4423879671803167], "isController": true}, {"data": ["Get Contact Request - 4", 1, 0, 0.0, 1055.0, 1055, 1055, 1055.0, 1055.0, 1055.0, 1055.0, 0.9478672985781991, 2.983375296208531, 0.48319016587677727], "isController": false}, {"data": ["ADD_CONTACT", 5, 1, 20.0, 1045.2, 1024, 1066, 1049.0, 1066.0, 1066.0, 1066.0, 0.4664179104477612, 0.49310940415111937, 0.3883475687966418], "isController": true}, {"data": ["PATCH_UPDATE_CONTACT", 5, 1, 20.0, 862.0, 3, 1128, 1056.0, 1128.0, 1128.0, 1128.0, 0.1594896331738437, 0.20023425039872408, 0.08310905103668262], "isController": true}, {"data": ["Get Contact Request - 5", 1, 0, 0.0, 1058.0, 1058, 1058, 1058.0, 1058.0, 1058.0, 1058.0, 0.945179584120983, 2.9915303048204156, 0.48182006143667294], "isController": false}, {"data": ["Get Contact Request - 2", 1, 0, 0.0, 1050.0, 1050, 1050, 1050.0, 1050.0, 1050.0, 1050.0, 0.9523809523809523, 2.710193452380952, 0.4854910714285714], "isController": false}, {"data": ["Update Contact Request - 2", 2, 2, 100.0, 15138.0, 3, 30273, 15138.0, 30273.0, 30273.0, 30273.0, 0.0660545610674417, 0.10824175143668671, 0.02944717492899135], "isController": false}, {"data": ["Update Contact Request - 1", 2, 0, 0.0, 1053.0, 1034, 1072, 1053.0, 1072.0, 1072.0, 1072.0, 0.9492168960607499, 0.9913940140009492, 0.7434296392975794], "isController": false}, {"data": ["Get Contact Request - 3", 1, 0, 0.0, 1052.0, 1052, 1052, 1052.0, 1052.0, 1052.0, 1052.0, 0.9505703422053232, 2.7050409933460076, 0.48456808460076045], "isController": false}, {"data": ["DELETE_CONTACT", 5, 1, 20.0, 7010.0, 1037, 30877, 1044.0, 30877.0, 30877.0, 30877.0, 0.08175678990140131, 0.06815194908187125, 0.05175268673250814], "isController": true}, {"data": ["Get Contact Request - 1", 1, 0, 0.0, 1131.0, 1131, 1131, 1131.0, 1131.0, 1131.0, 1131.0, 0.8841732979664013, 2.5160947170645445, 0.45072115384615385], "isController": false}, {"data": ["Add Contact Request - 2", 1, 1, 100.0, 1024.0, 1024, 1024, 1024.0, 1024.0, 1024.0, 1024.0, 0.9765625, 1.1014938354492188, 0.8134841918945312], "isController": false}, {"data": ["Add Contact Request - 1", 1, 0, 0.0, 1066.0, 1066, 1066, 1066.0, 1066.0, 1066.0, 1066.0, 0.9380863039399625, 0.9701498006566603, 0.7805171200750468], "isController": false}, {"data": ["Update Contact Request - 4", 2, 0, 0.0, 1085.0, 1042, 1128, 1085.0, 1128.0, 1128.0, 1128.0, 0.9208103130755064, 0.9617252244475137, 0.721181514732965], "isController": false}, {"data": ["Update Contact Request - 3", 2, 0, 0.0, 1046.0, 1041, 1051, 1046.0, 1051.0, 1051.0, 1051.0, 0.9551098376313276, 0.9956833512416429, 0.7480450095510984], "isController": false}, {"data": ["Update Contact Request - 5", 2, 0, 0.0, 1051.5, 1047, 1056, 1051.5, 1056.0, 1056.0, 1056.0, 0.9501187648456056, 0.9923359560570071, 0.7441359857482185], "isController": false}, {"data": ["PUT_UPDATE_CONTACT", 5, 1, 20.0, 6887.4, 1034, 30273, 1042.0, 30273.0, 30273.0, 30273.0, 0.15441153763009172, 0.16526859886970754, 0.14056878454958155], "isController": true}, {"data": ["Get Contact by ID Request - 1", 1, 0, 0.0, 1056.0, 1056, 1056, 1056.0, 1056.0, 1056.0, 1056.0, 0.946969696969697, 0.9858102509469696, 0.5058519767992424], "isController": false}, {"data": ["Get Contact by ID Request - 2", 1, 0, 0.0, 1089.0, 1089, 1089, 1089.0, 1089.0, 1089.0, 1089.0, 0.9182736455463728, 2.622998450413223, 0.4690010904499541], "isController": false}, {"data": ["Get Contact by ID Request - 3", 1, 0, 0.0, 1035.0, 1035, 1035, 1035.0, 1035.0, 1035.0, 1035.0, 0.966183574879227, 0.998263888888889, 0.5161156400966184], "isController": false}, {"data": ["Get Contact by ID Request - 4", 1, 0, 0.0, 1034.0, 1034, 1034, 1034.0, 1034.0, 1034.0, 1034.0, 0.9671179883945842, 1.0011182301740813, 0.5166147848162476], "isController": false}, {"data": ["Delete Contact Request - 5", 1, 0, 0.0, 1041.0, 1041, 1041, 1041.0, 1041.0, 1041.0, 1041.0, 0.9606147934678194, 0.7092038904899136, 0.6125795509125841], "isController": false}, {"data": ["Get Contact by ID Request - 5", 1, 0, 0.0, 1036.0, 1036, 1036, 1036.0, 1036.0, 1036.0, 1036.0, 0.9652509652509653, 1.0048413368725868, 0.515617458976834], "isController": false}, {"data": ["Delete Contact Request - 3", 1, 0, 0.0, 1044.0, 1044, 1044, 1044.0, 1044.0, 1044.0, 1044.0, 0.9578544061302682, 0.7034243295019157, 0.6108192648467433], "isController": false}, {"data": ["Delete Contact Request - 4", 1, 0, 0.0, 1051.0, 1051, 1051, 1051.0, 1051.0, 1051.0, 1051.0, 0.9514747859181732, 0.7061726926736442, 0.60675101094196], "isController": false}, {"data": ["Delete Contact Request - 1", 1, 0, 0.0, 1037.0, 1037, 1037, 1037.0, 1037.0, 1037.0, 1037.0, 0.9643201542912248, 0.7232401157184186, 0.6149424421407907], "isController": false}, {"data": ["Delete Contact Request - 2", 1, 1, 100.0, 30877.0, 30877, 30877, 30877.0, 30877.0, 30877.0, 30877.0, 0.032386566052401464, 0.03896508728179551, 0.019893701217734885], "isController": false}, {"data": ["AUTH Request", 5, 0, 0.0, 2753.2, 2645, 2969, 2725.0, 2969.0, 2969.0, 2969.0, 0.39556962025316456, 0.48665879647943033, 0.10623207575158228], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 1, 25.0, 2.857142857142857], "isController": false}, {"data": ["503/Service Unavailable", 2, 50.0, 5.714285714285714], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: thinking-tester-contact-list.herokuapp.com:443 failed to respond", 1, 25.0, 2.857142857142857], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 35, 4, "503/Service Unavailable", 2, "400/Bad Request", 1, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: thinking-tester-contact-list.herokuapp.com:443 failed to respond", 1, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Update Contact Request - 2", 2, 2, "503/Service Unavailable", 1, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: thinking-tester-contact-list.herokuapp.com:443 failed to respond", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Add Contact Request - 2", 1, 1, "400/Bad Request", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Delete Contact Request - 2", 1, 1, "503/Service Unavailable", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
